/home/root/espreso_m/env/threading.default 1
mpirun -n 4 espreso -c espreso.ecf 1 1 


